import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Stack;

public class HtmlAnalyzer {
    public static void main(String[] args) { 
        if (args.length != 1) {
            System.out.println("Uso: java HtmlAnalyzer <URL>");
            return;
        }

        try {
            String htmlContent = downloadHtml(args[0]);
            System.out.println(findDeepestText(htmlContent));
        } catch (Exception e) {
            System.out.println("Erro ao conectar à URL");
        }
    }

    private static String downloadHtml(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        if (connection.getResponseCode() != 200) throw new Exception();

        BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        StringBuilder html = new StringBuilder();
        String line;
        
        while ((line = reader.readLine()) != null) html.append(line).append("\n");
        
        return html.toString();
    }

    private static String findDeepestText(String html) {
        Stack<String> stack = new Stack<>();
        String deepest = "";
        int maxDepth = -1;

        for (String line : html.split("\n")) {
            line = line.trim();
            if (line.isEmpty()) continue;

            if (line.startsWith("<") && !line.startsWith("</")) {
                // Verifica se é uma tag de abertura
                stack.push(line);
            } else if (line.startsWith("</")) {
                // Verifica se é uma tag de fechamento
                if (stack.isEmpty()) {
                    return "Erro: Tag de fechamento '" + line + "' sem tag de abertura correspondente.";
                }
                String openedTag = stack.pop();
                String expectedClosingTag = "</" + openedTag.substring(1); // Remove '<' e adiciona '</'
                if (!line.equals(expectedClosingTag)) {
                    return "Erro: Tag de fechamento '" + line + "' nao corresponde a tag de abertura '" + openedTag + "'.";
                }
            } else {
                // É um texto fora de tags
                if (stack.size() > maxDepth) {
                    maxDepth = stack.size();
                    deepest = line;
                }
            }
        }

        // Verifica se há tags não fechadas
        if (!stack.isEmpty()) {
            StringBuilder errorMessage = new StringBuilder("Erro: As seguintes tags nao foram fechadas:\n");
            while (!stack.isEmpty()) {
                errorMessage.append("- ").append(stack.pop()).append("\n");
            }
            return errorMessage.toString();
        }

        return deepest.isEmpty() ? "Nenhum texto encontrado." : deepest;
    }
}